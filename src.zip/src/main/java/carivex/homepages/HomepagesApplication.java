package carivex.homepages;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomepagesApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomepagesApplication.class, args);
	}

}
