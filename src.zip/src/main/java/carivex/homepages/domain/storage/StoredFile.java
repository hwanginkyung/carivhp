package carivex.homepages.domain.storage;

public record StoredFile(
        String originalName,
        String storedName
) {}
